#define WIDTH 168
#define HEIGHT 145
#define BYTES 3045
#define BYTES_PER_LINE 21
